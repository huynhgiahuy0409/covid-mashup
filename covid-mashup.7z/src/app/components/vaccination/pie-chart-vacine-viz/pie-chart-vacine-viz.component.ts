import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pie-chart-vacine-viz',
  templateUrl: './pie-chart-vacine-viz.component.html',
  styleUrls: ['./pie-chart-vacine-viz.component.scss']
})
export class PieChartVacineVizComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
